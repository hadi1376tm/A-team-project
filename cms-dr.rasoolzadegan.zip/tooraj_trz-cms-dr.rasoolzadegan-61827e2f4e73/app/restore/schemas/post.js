module.exports = {
    'password' : 'string',
    'file' : ['string', 'length:min,3'],
};


