module.exports = {
    'password' : 'string',
    'newPassword?' : 'string',
    'newPath?' : 'string',
    'collections?' : 'array',
    'collections.*' : 'string'
};
