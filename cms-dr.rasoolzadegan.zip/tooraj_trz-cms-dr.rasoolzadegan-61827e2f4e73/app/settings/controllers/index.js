const post = require('./post');
const get = require('./get');

module.exports = {
    post,
    get
};
