const get = require('./get');

module.exports={
    getByCode: get.getByCode,
    getById:get.getById,
}