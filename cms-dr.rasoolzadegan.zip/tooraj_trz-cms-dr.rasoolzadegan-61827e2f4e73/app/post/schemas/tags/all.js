module.exports = {
    type: 'object',
    'properties' : {
        "page" : {
            "type" : "number",
        },
        "size" : {
            "type" : "number",
        },
        "sortBy" : {
            "type" : "string",
        },
    }
}
