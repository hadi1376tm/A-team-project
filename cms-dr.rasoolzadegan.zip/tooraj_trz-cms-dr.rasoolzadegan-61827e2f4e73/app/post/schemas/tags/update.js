module.exports = {
    type: 'object',
    'properties' : {
        "name": {
            "type": "string",
        }
    },
    "required" : [ "name", ]
}
