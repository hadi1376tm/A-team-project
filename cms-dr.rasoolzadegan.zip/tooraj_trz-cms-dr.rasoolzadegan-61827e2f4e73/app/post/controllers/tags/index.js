const all = require('./all');
const update = require('./update');
module.exports={
    all,
    update
}
