module.exports = {
    'collections?' : 'array',
    'collections.*.name' : ['string', 'length:min,1'],
    'is_full' : 'boolean', 
};
