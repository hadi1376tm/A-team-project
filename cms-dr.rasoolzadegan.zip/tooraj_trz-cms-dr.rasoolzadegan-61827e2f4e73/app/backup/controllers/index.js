const post = require('./post');
const get = require('./get');
const _delete = require('./delete');

module.exports = {
    post,
    get,
    _delete,
};
